#include <QtGui>

#define BITS_PER_PIXEL 32	// We work only with 32 bit