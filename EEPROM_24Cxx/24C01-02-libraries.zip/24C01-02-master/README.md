24C01-02
========

Arduino library for 24C01/02 serial EEPROM
